package com.action;

import com.dao.UserDao;

public class Test {
public static void main(String[] args) {
	UserDao.deleteUser(1);
}
}
